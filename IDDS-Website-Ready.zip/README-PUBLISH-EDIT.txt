IDDS WEBSITE FILES
==================

Main website file: index.html
Keep all image files in the same folder as index.html.

Important:
- The chairman image is available as president.jpg and president.jpg.jpg.
- The gallery image aliases were added to match the image paths used in index.html.
- Do not delete the image files or move them into a separate folder.

To publish free:
1. Create/sign in to a GitHub account.
2. Create a public repository named idds-website.
3. Upload ALL files in this folder (not just index.html).
4. Open Settings > Pages.
5. Select Deploy from a branch, branch main, folder / (root), Save.
6. The temporary free address will be https://YOUR-USERNAME.github.io/idds-website/

To edit later:
- Open the repository on GitHub.
- Click index.html, then the pencil/Edit button.
- Make changes and Commit changes.
- For images, upload replacement image files using the same filenames.

Custom domain:
www.idds.org can only be used after the domain is registered/owned and its DNS is configured to the hosting provider.
A free GitHub Pages address does not automatically provide www.idds.org.
